
package com.kiet.studentskillmanagement.repository;

import com.kiet.studentskillmanagement.model.Student;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class StudentRepository {

    private final JdbcTemplate jdbc;

    public StudentRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    // Add student
    public void addStudent(Student s) {
        String sql = "INSERT INTO students VALUES (?, ?, ?, ?, ?, ?)";
        jdbc.update(sql,
            s.getStudentId(),
            s.getStudentName(),
            s.getEmail(),
            s.getCourseName(),
            s.getProgrammingScore(),
            s.getMathematicsScore()
        );

        for (String skill : s.getTechnicalSkills()) {
            jdbc.update(
                "INSERT INTO student_skills(student_id, skill) VALUES (?, ?)",
                s.getStudentId(), skill
            );
        }
    }

    // Get all students
    public List<Student> getAllStudents() {
        String sql = "SELECT * FROM students";

        return jdbc.query(sql, (rs, rowNum) -> {
            Student s = new Student();
            s.setStudentId(rs.getInt("student_id"));
            s.setStudentName(rs.getString("student_name"));
            s.setEmail(rs.getString("email"));
            s.setCourseName(rs.getString("course_name"));
            s.setProgrammingScore(rs.getDouble("programming_score"));
            s.setMathematicsScore(rs.getDouble("mathematics_score"));

            List<String> skills = jdbc.query(
                "SELECT skill FROM student_skills WHERE student_id = ?",
                (r, n) -> r.getString("skill"),
                s.getStudentId()
            );
            s.setTechnicalSkills(skills);
            return s;
        });
    }

    // Find student by ID
    public Student findById(int id) {
        List<Student> list = jdbc.query(
            "SELECT * FROM students WHERE student_id = ?",
            (rs, rowNum) -> {
                Student s = new Student();
                s.setStudentId(rs.getInt("student_id"));
                s.setStudentName(rs.getString("student_name"));
                s.setEmail(rs.getString("email"));
                s.setCourseName(rs.getString("course_name"));
                s.setProgrammingScore(rs.getDouble("programming_score"));
                s.setMathematicsScore(rs.getDouble("mathematics_score"));
                return s;
            }, id
        );

        if (list.isEmpty()) return null;

        Student s = list.get(0);
        s.setTechnicalSkills(jdbc.query(
            "SELECT skill FROM student_skills WHERE student_id = ?",
            (rs, rowNum) -> rs.getString("skill"), id
        ));
        return s;
    }

    // Update scores and skills
    public void updateStudent(int id, Student s) {
        jdbc.update(
            "UPDATE students SET programming_score=?, mathematics_score=? WHERE student_id=?",
            s.getProgrammingScore(), s.getMathematicsScore(), id
        );

        jdbc.update("DELETE FROM student_skills WHERE student_id=?", id);

        for (String skill : s.getTechnicalSkills()) {
            jdbc.update(
                "INSERT INTO student_skills(student_id, skill) VALUES (?, ?)",
                id, skill
            );
        }
    }

    // Delete student
    public void deleteStudent(int id) {
        jdbc.update("DELETE FROM students WHERE student_id=?", id);
    }
}
