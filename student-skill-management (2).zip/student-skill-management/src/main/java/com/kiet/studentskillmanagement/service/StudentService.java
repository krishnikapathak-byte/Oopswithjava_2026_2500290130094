
package com.kiet.studentskillmanagement.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.kiet.studentskillmanagement.model.Student;
import com.kiet.studentskillmanagement.repository.StudentRepository;

@Service
public class StudentService {

    private final StudentRepository repository;

    public StudentService(StudentRepository repository) {
        this.repository = repository;
    }

    // Validate marks
    private void validateScores(Student s) {
        if (s.getProgrammingScore() < 0 ||
            s.getProgrammingScore() > 100 ||
            s.getMathematicsScore() < 0 ||
            s.getMathematicsScore() > 100) {
            throw new RuntimeException("Scores must be between 0 and 100");
        }
    }

    // Add student
    public void addStudent(Student s) {
        validateScores(s);

        if (repository.findById(s.getStudentId()) != null) {
            throw new RuntimeException("Student ID already exists");
        }

        repository.addStudent(s);
    }

    // Get all students
    public List<Student> getAllStudents() {
        return repository.getAllStudents();
    }

    // Search by ID
    public Student getStudentById(int id) {
        return repository.findById(id);
    }

    // Search by email
    public List<Student> searchByEmail(String email) {
        List<Student> result = new ArrayList<>();

        for (Student s : getAllStudents()) {
            if (s.getEmail().equalsIgnoreCase(email)) {
                result.add(s);
            }
        }
        return result;
    }

    // Search by course
    public List<Student> searchByCourse(String course) {
        List<Student> result = new ArrayList<>();

        for (Student s : getAllStudents()) {
            if (s.getCourseName().equalsIgnoreCase(course)) {
                result.add(s);
            }
        }
        return result;
    }

    // Performance category
    public String getCategory(Student s) {
        double avg = s.calculateAverage();

        if (avg >= 85) return "Excellent";
        else if (avg >= 70) return "Good";
        else if (avg >= 50) return "Satisfactory";
        else return "Needs Improvement";
    }

    // Stronger subject
    public String getStrongerSubject(Student s) {
        if (s.getProgrammingScore() > s.getMathematicsScore())
            return "Programming";
        else if (s.getMathematicsScore() > s.getProgrammingScore())
            return "Mathematics";
        else
            return "Equal";
    }

    // Merit list
    public List<Student> getMeritList() {
        List<Student> list = getAllStudents();

        list.sort((a, b) ->
            Double.compare(b.calculateAverage(), a.calculateAverage()));

        return list;
    }

    // Students with same technical skills
    public Map<Set<String>, List<Student>> getStudentsWithSameSkills() {
        Map<Set<String>, List<Student>> groups = new HashMap<>();

        for (Student s : getAllStudents()) {
            Set<String> skills = new HashSet<>(s.getTechnicalSkills());

            if (!groups.containsKey(skills)) {
                groups.put(skills, new ArrayList<>());
            }

            groups.get(skills).add(s);
        }

        groups.entrySet().removeIf(e -> e.getValue().size() < 2);

        return groups;
    }

    // Programming below 50 and Mathematics >= 75
    public List<Student> getStudentsNeedingProgrammingImprovement() {
        List<Student> result = new ArrayList<>();

        for (Student s : getAllStudents()) {
            if (s.getProgrammingScore() < 50 &&
                s.getMathematicsScore() >= 75) {
                result.add(s);
            }
        }

        return result;
    }

    // Update student
    public void updateStudent(int id, Student s) {
        validateScores(s);

        if (repository.findById(id) == null) {
            throw new RuntimeException("Student not found");
        }

        repository.updateStudent(id, s);
    }

    // Delete student
    public void deleteStudent(int id) {
        if (repository.findById(id) == null) {
            throw new RuntimeException("Student not found");
        }

        repository.deleteStudent(id);
    }
}
