
package com.kiet.studentskillmanagement.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kiet.studentskillmanagement.model.Student;
import com.kiet.studentskillmanagement.service.StudentService;

@RestController
@RequestMapping("/students")
public class StudentController {

    private final StudentService service;

    public StudentController(StudentService service) {
        this.service = service;
    }

    // Add student
    @PostMapping
    public String addStudent(@RequestBody Student s) {
        service.addStudent(s);
        return "Student added successfully";
    }

    // Get all students
    @GetMapping
    public List<Student> getAllStudents() {
        return service.getAllStudents();
    }

    // Search by ID
    @GetMapping("/{id}")
    public Student getStudentById(@PathVariable int id) {
        return service.getStudentById(id);
    }

    // Update scores and skills
    @PutMapping("/{id}")
    public String updateStudent(@PathVariable int id,
                                @RequestBody Student s) {
        service.updateStudent(id, s);
        return "Student updated successfully";
    }

    // Delete student
    @DeleteMapping("/{id}")
    public String deleteStudent(@PathVariable int id) {
        service.deleteStudent(id);
        return "Student deleted successfully";
    }

    // Merit list
    @GetMapping("/merit-list")
    public List<Student> getMeritList() {
        return service.getMeritList();
    }

    // Search by email
    @GetMapping("/search/email")
    public List<Student> searchByEmail(@RequestParam String email) {
        return service.searchByEmail(email);
    }

    // Search by course
    @GetMapping("/search/course")
    public List<Student> searchByCourse(@RequestParam String course) {
        return service.searchByCourse(course);
    }
    @GetMapping("/{id}/performance")
public Map<String, Object> getPerformance(@PathVariable int id) {
    Student s = service.getStudentById(id);

    if (s == null) {
        throw new RuntimeException("Student not found");
    }

    Map<String, Object> result = new HashMap<>();
    result.put("average", s.calculateAverage());
    result.put("category", service.getCategory(s));
    result.put("strongerSubject", service.getStrongerSubject(s));

    return result;
}
}
